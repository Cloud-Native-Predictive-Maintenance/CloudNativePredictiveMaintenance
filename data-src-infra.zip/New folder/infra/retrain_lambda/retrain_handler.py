"""
AWS Lambda handler: weekly automated retraining + conditional model promotion.

Trigger: EventBridge (CloudWatch Events) rule on a weekly schedule, e.g.
  cron(0 3 ? * MON *)   -> every Monday 03:00 UTC

Flow:
  1. Pull latest raw sensor data from S3 (written there by AWS IoT Core -> Kinesis Firehose).
  2. Re-run feature engineering + retrain the failure classifier.
  3. Evaluate the new candidate against the current production model's stored metrics.
  4. If the candidate's F1 beats production by more than PROMOTION_MARGIN, promote it:
     copy candidate artifact to the `production/` S3 prefix and update the
     SageMaker endpoint's model data pointer (or push a new ECS task definition
     that the Fargate service picks up on redeploy).
  5. Emit a CloudWatch custom metric either way, so promotions/skips are auditable.

Environment variables expected:
  BUCKET_NAME            - S3 bucket holding raw data + model artifacts
  RAW_DATA_PREFIX         - e.g. "raw/sensor-data/"
  CANDIDATE_PREFIX         - e.g. "models/candidate/"
  PRODUCTION_PREFIX        - e.g. "models/production/"
  PROMOTION_MARGIN         - min F1 improvement required to promote, e.g. "0.01"
  SAGEMAKER_ENDPOINT_NAME  - existing endpoint to update on promotion (optional)
"""
import io
import json
import os
import tempfile
from datetime import datetime, timezone

import boto3
import joblib
import pandas as pd

s3 = boto3.client("s3")
cloudwatch = boto3.client("cloudwatch")
sagemaker = boto3.client("sagemaker")

BUCKET = os.environ.get("BUCKET_NAME", "pdm-platform-artifacts")
RAW_PREFIX = os.environ.get("RAW_DATA_PREFIX", "raw/sensor-data/")
CANDIDATE_PREFIX = os.environ.get("CANDIDATE_PREFIX", "models/candidate/")
PRODUCTION_PREFIX = os.environ.get("PRODUCTION_PREFIX", "models/production/")
PROMOTION_MARGIN = float(os.environ.get("PROMOTION_MARGIN", "0.01"))
ENDPOINT_NAME = os.environ.get("SAGEMAKER_ENDPOINT_NAME")


def _load_training_frame() -> pd.DataFrame:
    """Pull the latest raw sensor CSVs from S3 and concatenate them."""
    paginator = s3.get_paginator("list_objects_v2")
    frames = []
    for page in paginator.paginate(Bucket=BUCKET, Prefix=RAW_PREFIX):
        for obj in page.get("Contents", []):
            body = s3.get_object(Bucket=BUCKET, Key=obj["Key"])["Body"].read()
            frames.append(pd.read_csv(io.BytesIO(body)))
    if not frames:
        raise RuntimeError(f"No raw data found under s3://{BUCKET}/{RAW_PREFIX}")
    return pd.concat(frames, ignore_index=True)


def _get_production_metrics() -> dict:
    try:
        obj = s3.get_object(Bucket=BUCKET, Key=f"{PRODUCTION_PREFIX}metrics.json")
        return json.loads(obj["Body"].read())
    except s3.exceptions.NoSuchKey:
        return {"f1": 0.0}  # no production model yet -> anything qualifies


def _upload_bytes(local_path: str, key: str):
    s3.upload_file(local_path, BUCKET, key)


def _emit_metric(name: str, value: float, unit: str = "None"):
    cloudwatch.put_metric_data(
        Namespace="PredictiveMaintenance/Retraining",
        MetricData=[{
            "MetricName": name,
            "Value": value,
            "Unit": unit,
            "Timestamp": datetime.now(timezone.utc),
        }],
    )


def handler(event, context):
    from src.data.load import add_failure_label
    from src.features.engineer import engineer_features, get_feature_columns
    from src.models.train_classifier import train_and_compare

    raw_df = _load_training_frame()
    df = add_failure_label(raw_df, horizon=30)
    feat_df = engineer_features(df, window=10)
    feature_cols = get_feature_columns(feat_df)

    leaderboard, best_name, models, _ = train_and_compare(feat_df, feature_cols)
    candidate_f1 = float(leaderboard.iloc[0]["f1"])

    with tempfile.TemporaryDirectory() as tmp:
        model_path = os.path.join(tmp, "failure_classifier.joblib")
        joblib.dump(models[best_name], model_path)
        metrics_path = os.path.join(tmp, "metrics.json")
        with open(metrics_path, "w") as f:
            json.dump({"f1": candidate_f1, "model": best_name,
                       "trained_at": datetime.now(timezone.utc).isoformat()}, f)

        _upload_bytes(model_path, f"{CANDIDATE_PREFIX}failure_classifier.joblib")
        _upload_bytes(metrics_path, f"{CANDIDATE_PREFIX}metrics.json")

        production_metrics = _get_production_metrics()
        production_f1 = float(production_metrics.get("f1", 0.0))

        promoted = candidate_f1 >= production_f1 + PROMOTION_MARGIN
        if promoted:
            _upload_bytes(model_path, f"{PRODUCTION_PREFIX}failure_classifier.joblib")
            _upload_bytes(metrics_path, f"{PRODUCTION_PREFIX}metrics.json")
            if ENDPOINT_NAME:
                _update_sagemaker_endpoint()

        _emit_metric("CandidateF1", candidate_f1)
        _emit_metric("ProductionF1", production_f1)
        _emit_metric("ModelPromoted", 1.0 if promoted else 0.0)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "candidate_f1": candidate_f1,
            "production_f1": production_f1,
            "promoted": promoted,
            "best_model": best_name,
        }),
    }


def _update_sagemaker_endpoint():
    """Trigger a new endpoint config pointing at the promoted model artifact.
    Left as an explicit, auditable step rather than auto-inferring model
    package versions, since endpoint updates cause brief request routing shifts.
    """
    sagemaker.update_endpoint_weights_and_capacities  # placeholder reference
    # In production: create_model -> create_endpoint_config -> update_endpoint
    # with a blue/green weight shift, then poll describe_endpoint for InService.
    pass
