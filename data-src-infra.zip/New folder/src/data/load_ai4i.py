"""Load the real AI4I 2020 Predictive Maintenance dataset.

Unlike C-MAPSS, this is NOT a time series — each row is one independent
machine/product instance with a snapshot of sensor readings and whether it
failed. So there's no RUL/run-to-failure concept here; this dataset is used
for failure classification and anomaly detection only.

Columns: UDI, Product ID, Type (L/M/H quality variant), Air temperature [K],
Process temperature [K], Rotational speed [rpm], Torque [Nm], Tool wear [min],
Machine failure (binary target), and 5 specific-failure-mode flags
(TWF, HDF, PWF, OSF, RNF) that we keep for reference but don't feed to the model.
"""
import pandas as pd
from pathlib import Path

RAW_PATH = Path(__file__).resolve().parents[2] / "data" / "raw_ai4i" / "ai4i2020.csv"

RENAME = {
    "Air temperature [K]": "air_temp_k",
    "Process temperature [K]": "process_temp_k",
    "Rotational speed [rpm]": "rotational_speed_rpm",
    "Torque [Nm]": "torque_nm",
    "Tool wear [min]": "tool_wear_min",
    "Machine failure": "machine_failure",
}

FAILURE_MODE_COLS = ["TWF", "HDF", "PWF", "OSF", "RNF"]


def load(path: Path = RAW_PATH) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.rename(columns=RENAME)
    df["type"] = df["Type"]  # keep raw categorical for one-hot encoding downstream
    return df
