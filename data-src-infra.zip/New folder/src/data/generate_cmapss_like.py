"""
Generates a synthetic dataset with the EXACT schema of NASA C-MAPSS
(unit_number, time_in_cycles, 3 op settings, 21 sensors) so the rest of the
pipeline (feature engineering, training, serving) is a drop-in replacement
for the real dataset. Simulates run-to-failure degradation trajectories.

To use the REAL NASA C-MAPSS dataset instead:
  1. Download train_FD001.txt / test_FD001.txt / RUL_FD001.txt from the
     NASA Prognostics Data Repository.
  2. Place them in data/raw/.
  3. Point src/data/load.py at the real files (same column layout below).
"""
import numpy as np
import pandas as pd
from pathlib import Path

RNG = np.random.default_rng(42)

COLS = (
    ["unit_number", "time_in_cycles", "op_setting_1", "op_setting_2", "op_setting_3"]
    + [f"sensor_{i}" for i in range(1, 22)]
)


def _simulate_unit(unit_id: int, life: int) -> pd.DataFrame:
    """One engine's run-to-failure trajectory: sensors drift/degrade with cycles."""
    t = np.arange(1, life + 1)
    frac = t / life  # 0 -> healthy, 1 -> failure

    op1 = RNG.normal(0, 0.002, life)
    op2 = RNG.normal(0, 0.0003, life)
    op3 = np.full(life, 100.0)

    sensors = {}
    # A subset of sensors show clear degradation trend (like real CMAPSS: 2,3,4,7,8,9,11,12,13,14,15,17,20,21)
    degrading = {2, 3, 4, 7, 8, 9, 11, 12, 13, 14, 15, 17, 20, 21}
    for i in range(1, 22):
        base = RNG.uniform(400, 600)
        noise = RNG.normal(0, 1.0, life)
        if i in degrading:
            drift_dir = RNG.choice([-1, 1])
            trend = drift_dir * (frac ** 1.5) * RNG.uniform(15, 45)
            sensors[f"sensor_{i}"] = base + trend + noise
        else:
            sensors[f"sensor_{i}"] = base + noise

    df = pd.DataFrame({
        "unit_number": unit_id,
        "time_in_cycles": t,
        "op_setting_1": op1,
        "op_setting_2": op2,
        "op_setting_3": op3,
        **sensors,
    })
    return df


def generate(n_units: int = 100, min_life: int = 128, max_life: int = 362) -> pd.DataFrame:
    lives = RNG.integers(min_life, max_life, n_units)
    frames = [_simulate_unit(u + 1, int(life)) for u, life in enumerate(lives)]
    return pd.concat(frames, ignore_index=True)[COLS]


if __name__ == "__main__":
    out_dir = Path(__file__).resolve().parents[2] / "data" / "raw"
    out_dir.mkdir(parents=True, exist_ok=True)

    train = generate(n_units=100)
    train.to_csv(out_dir / "train_FD001.txt", sep=" ", header=False, index=False)

    # test set: truncate each unit's run partway through life, hold out true RUL
    test_units = generate(n_units=40, min_life=128, max_life=300)
    truncated = []
    rul_truth = []
    for uid, grp in test_units.groupby("unit_number"):
        cut = RNG.integers(int(len(grp) * 0.4), int(len(grp) * 0.9))
        truncated.append(grp.iloc[:cut])
        rul_truth.append(len(grp) - cut)
    test_df = pd.concat(truncated, ignore_index=True)
    test_df.to_csv(out_dir / "test_FD001.txt", sep=" ", header=False, index=False)
    pd.Series(rul_truth).to_csv(out_dir / "RUL_FD001.txt", header=False, index=False)

    print(f"train: {train.shape}, units: {train.unit_number.nunique()}")
    print(f"test:  {test_df.shape}, units: {test_df.unit_number.nunique()}")
    print(f"wrote to {out_dir}")
