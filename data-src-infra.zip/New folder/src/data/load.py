"""Load raw C-MAPSS-format sensor logs and attach RUL / failure labels."""
import pandas as pd
from pathlib import Path

COLS = (
    ["unit_number", "time_in_cycles", "op_setting_1", "op_setting_2", "op_setting_3"]
    + [f"sensor_{i}" for i in range(1, 22)]
)

RAW_DIR = Path(__file__).resolve().parents[2] / "data" / "raw"


def load_train(path: Path = RAW_DIR / "train_FD001.txt") -> pd.DataFrame:
    df = pd.read_csv(path, sep=r"\s+", header=None, names=COLS)
    max_cycle = df.groupby("unit_number")["time_in_cycles"].transform("max")
    df["RUL"] = max_cycle - df["time_in_cycles"]
    return df


def load_test(
    path: Path = RAW_DIR / "test_FD001.txt",
    rul_path: Path = RAW_DIR / "RUL_FD001.txt",
) -> pd.DataFrame:
    df = pd.read_csv(path, sep=r"\s+", header=None, names=COLS)
    rul_truth = pd.read_csv(rul_path, header=None, names=["RUL_at_cutoff"])
    rul_truth["unit_number"] = rul_truth.index + 1

    last_cycle = df.groupby("unit_number")["time_in_cycles"].transform("max")
    df["cycles_from_cutoff"] = last_cycle - df["time_in_cycles"]
    df = df.merge(rul_truth, on="unit_number", how="left")
    df["RUL"] = df["cycles_from_cutoff"] + df["RUL_at_cutoff"]
    df = df.drop(columns=["cycles_from_cutoff", "RUL_at_cutoff"])
    return df


def add_failure_label(df: pd.DataFrame, horizon: int = 30) -> pd.DataFrame:
    """Binary label: will this unit fail within `horizon` cycles from now?"""
    df = df.copy()
    df["failure_within_horizon"] = (df["RUL"] <= horizon).astype(int)
    return df
