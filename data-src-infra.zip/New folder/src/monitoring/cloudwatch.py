"""Lightweight monitoring hooks: log every served prediction as a CloudWatch
custom metric so dashboards/alarms can track volume, risk distribution, and
latency without a separate observability stack.

Wire into src/serving/main.py by calling `log_prediction(...)` at the end of
the /predict handler. Left as an opt-in import (rather than hard-wired) so
the API still runs locally without AWS credentials configured.
"""
import os
import time
from contextlib import contextmanager

try:
    import boto3
    _cloudwatch = boto3.client("cloudwatch") if os.environ.get("AWS_DEFAULT_REGION") else None
except ImportError:
    _cloudwatch = None

NAMESPACE = "PredictiveMaintenance/Serving"


def log_prediction(machine_id: str, failure_probability: float, health_status: str,
                    is_anomaly: bool, latency_ms: float):
    if _cloudwatch is None:
        return  # no-op locally / without AWS creds — never blocks a response
    metrics = [
        {"MetricName": "FailureProbability", "Value": failure_probability, "Unit": "None"},
        {"MetricName": "PredictionLatencyMs", "Value": latency_ms, "Unit": "Milliseconds"},
        {"MetricName": "AnomalyFlagged", "Value": 1.0 if is_anomaly else 0.0, "Unit": "Count"},
        {"MetricName": f"HealthStatus_{health_status.replace(' ', '')}", "Value": 1.0, "Unit": "Count"},
    ]
    try:
        _cloudwatch.put_metric_data(Namespace=NAMESPACE, MetricData=metrics)
    except Exception:
        pass  # monitoring must never take down the serving path


@contextmanager
def timed():
    start = time.perf_counter()
    result = {}
    yield result
    result["latency_ms"] = (time.perf_counter() - start) * 1000
