"""Automated feature engineering on raw sensor streams.

For each unit's time series we compute, per sensor:
  - rolling mean / std over a window (smoothed current state)
  - short-term trend slope (rate of degradation)
  - delta from that unit's first-cycle baseline (drift)
Plus cycle-level context (time_in_cycles itself is predictive in CMAPSS-style data).
"""
import numpy as np
import pandas as pd

SENSOR_COLS = [f"sensor_{i}" for i in range(1, 22)]
OP_COLS = ["op_setting_1", "op_setting_2", "op_setting_3"]


def _rolling_slope(s: pd.Series, window: int) -> pd.Series:
    def slope(x):
        if len(x) < 2:
            return 0.0
        idx = np.arange(len(x))
        return np.polyfit(idx, x, 1)[0]
    return s.rolling(window, min_periods=2).apply(slope, raw=True)


def engineer_features(df: pd.DataFrame, window: int = 10) -> pd.DataFrame:
    df = df.sort_values(["unit_number", "time_in_cycles"]).copy()
    out_frames = []

    for uid, g in df.groupby("unit_number", sort=False):
        g = g.copy()
        baseline = g[SENSOR_COLS].iloc[0]

        for col in SENSOR_COLS:
            g[f"{col}_roll_mean"] = g[col].rolling(window, min_periods=1).mean()
            g[f"{col}_roll_std"] = g[col].rolling(window, min_periods=1).std().fillna(0)
            g[f"{col}_slope"] = _rolling_slope(g[col], window).fillna(0)
            g[f"{col}_delta_baseline"] = g[col] - baseline[col]

        out_frames.append(g)

    feat_df = pd.concat(out_frames, ignore_index=True)
    return feat_df


def get_feature_columns(df: pd.DataFrame) -> list[str]:
    exclude = {"unit_number", "time_in_cycles", "RUL", "failure_within_horizon"}
    return [c for c in df.columns if c not in exclude]
