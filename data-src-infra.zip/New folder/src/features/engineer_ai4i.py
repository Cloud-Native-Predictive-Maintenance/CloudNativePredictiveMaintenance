"""Feature engineering for AI4I 2020 — a per-instance tabular dataset, so
there's no rolling/trend features here (that needs a time series). Instead
we derive physically meaningful combinations, which tends to help tree
models find the real failure boundary faster than raw columns alone.
"""
import numpy as np
import pandas as pd

RAW_NUMERIC = [
    "air_temp_k", "process_temp_k", "rotational_speed_rpm",
    "torque_nm", "tool_wear_min",
]


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    df["temp_diff_k"] = df["process_temp_k"] - df["air_temp_k"]

    # Mechanical power (W) = torque (Nm) * angular velocity (rad/s).
    # rpm -> rad/s: * 2*pi / 60
    df["power_w"] = df["torque_nm"] * df["rotational_speed_rpm"] * (2 * np.pi / 60)

    # Tool-wear failure in the real dataset is driven by an interaction between
    # wear and torque — high torque accelerates wear-related failure.
    df["wear_torque_interaction"] = df["tool_wear_min"] * df["torque_nm"]

    # One-hot encode product quality variant (L/M/H)
    df = pd.get_dummies(df, columns=["type"], prefix="type", dtype=int)

    return df


def get_feature_columns(df: pd.DataFrame) -> list[str]:
    exclude = {
        "UDI", "Product ID", "Type", "machine_failure",
        "TWF", "HDF", "PWF", "OSF", "RNF",
    }
    return [c for c in df.columns if c not in exclude]
