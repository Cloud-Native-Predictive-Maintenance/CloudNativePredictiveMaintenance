"""
SageMaker training entry point. Packaged into a SageMaker Training Job via
the XGBoost/Sklearn framework container; SageMaker invokes this script with
SM_* environment variables set (channels, model dir, hyperparameters).

Local equivalent of this same logic: src/models/train_classifier.py, which
this script wraps for the managed-training environment.

Example (from a SageMaker notebook / pipeline):

    from sagemaker.sklearn.estimator import SKLearn

    estimator = SKLearn(
        entry_point="sagemaker_train.py",
        source_dir="src",
        role=sagemaker_role,
        instance_type="ml.m5.xlarge",
        framework_version="1.2-1",
        hyperparameters={"horizon": 30, "window": 10},
    )
    estimator.fit({"train": "s3://pdm-platform-artifacts/raw/sensor-data/"})
"""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import joblib
import pandas as pd

from src.data.load import add_failure_label
from src.features.engineer import engineer_features, get_feature_columns
from src.models.train_classifier import train_and_compare


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--horizon", type=int, default=30)
    parser.add_argument("--window", type=int, default=10)
    # SageMaker-injected paths
    parser.add_argument("--model-dir", type=str, default=os.environ.get("SM_MODEL_DIR", "models"))
    parser.add_argument("--train", type=str, default=os.environ.get("SM_CHANNEL_TRAIN", "data/raw"))
    return parser.parse_args()


def main():
    args = parse_args()

    train_files = list(Path(args.train).glob("train_*.txt"))
    if not train_files:
        raise FileNotFoundError(f"No train_*.txt files found under {args.train}")

    cols = (
        ["unit_number", "time_in_cycles", "op_setting_1", "op_setting_2", "op_setting_3"]
        + [f"sensor_{i}" for i in range(1, 22)]
    )
    raw_df = pd.read_csv(train_files[0], sep=r"\s+", header=None, names=cols)
    max_cycle = raw_df.groupby("unit_number")["time_in_cycles"].transform("max")
    raw_df["RUL"] = max_cycle - raw_df["time_in_cycles"]

    df = add_failure_label(raw_df, horizon=args.horizon)
    feat_df = engineer_features(df, window=args.window)
    feature_cols = get_feature_columns(feat_df)

    leaderboard, best_name, models, _ = train_and_compare(feat_df, feature_cols)
    print(leaderboard.to_string(index=False))

    model_dir = Path(args.model_dir)
    model_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(models[best_name], model_dir / "model.joblib")
    joblib.dump(feature_cols, model_dir / "feature_columns.joblib")
    print(f"Saved best model ({best_name}) to {model_dir / 'model.joblib'}")


if __name__ == "__main__":
    main()
