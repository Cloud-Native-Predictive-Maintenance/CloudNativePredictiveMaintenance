"""Train an Isolation Forest anomaly detector on healthy-operation sensor data."""
import joblib
import pandas as pd
from pathlib import Path
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

MODEL_DIR = Path(__file__).resolve().parents[2] / "models"
MODEL_DIR.mkdir(exist_ok=True)


def train_isolation_forest(df: pd.DataFrame, feature_cols: list[str], contamination: float = 0.05):
    # Train primarily on early-life (healthy) cycles so "normal" is well defined
    healthy = df[df["RUL"] > df["RUL"].quantile(0.5)]

    scaler = StandardScaler()
    X_healthy = scaler.fit_transform(healthy[feature_cols])

    iso = IsolationForest(
        n_estimators=300, contamination=contamination,
        random_state=42, n_jobs=-1,
    )
    iso.fit(X_healthy)

    X_all = scaler.transform(df[feature_cols])
    scores = iso.decision_function(X_all)          # higher = more normal
    flags = iso.predict(X_all)                      # -1 = anomaly, 1 = normal

    joblib.dump(iso, MODEL_DIR / "anomaly_detector.joblib")
    joblib.dump(scaler, MODEL_DIR / "anomaly_scaler.joblib")
    joblib.dump(feature_cols, MODEL_DIR / "anomaly_features.joblib")

    out = df[["unit_number", "time_in_cycles", "RUL"]].copy()
    out["anomaly_score"] = scores
    out["is_anomaly"] = (flags == -1).astype(int)
    return iso, scaler, out
