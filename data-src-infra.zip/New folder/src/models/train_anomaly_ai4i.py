"""Isolation Forest anomaly detection trained on non-failed AI4I machines."""
import joblib
import pandas as pd
from pathlib import Path
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

MODEL_DIR = Path(__file__).resolve().parents[2] / "models_ai4i"
MODEL_DIR.mkdir(exist_ok=True)


def train_isolation_forest(df: pd.DataFrame, feature_cols: list[str], contamination: float = 0.05):
    healthy = df[df["machine_failure"] == 0]

    scaler = StandardScaler()
    X_healthy = scaler.fit_transform(healthy[feature_cols])

    iso = IsolationForest(n_estimators=300, contamination=contamination, random_state=42, n_jobs=-1)
    iso.fit(X_healthy)

    X_all = scaler.transform(df[feature_cols])
    scores = iso.decision_function(X_all)
    flags = iso.predict(X_all)

    joblib.dump(iso, MODEL_DIR / "anomaly_detector.joblib")
    joblib.dump(scaler, MODEL_DIR / "anomaly_scaler.joblib")
    joblib.dump(feature_cols, MODEL_DIR / "anomaly_features.joblib")

    out = df[["UDI", "machine_failure"]].copy()
    out["anomaly_score"] = scores
    out["is_anomaly"] = (flags == -1).astype(int)
    return iso, scaler, out
