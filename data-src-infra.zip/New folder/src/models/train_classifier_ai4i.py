"""Train and compare failure-classification models on AI4I 2020.

Unlike the C-MAPSS pipeline, rows here are independent machine instances
(not a time series for the same unit), so a plain stratified train/test
split is correct — no need for GroupShuffleSplit.
"""
import joblib
import pandas as pd
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score
import xgboost as xgb
import lightgbm as lgb

MODEL_DIR = Path(__file__).resolve().parents[2] / "models_ai4i"
MODEL_DIR.mkdir(exist_ok=True)


def _eval(name, y_test, preds, probs):
    return {
        "model": name,
        "precision": round(precision_score(y_test, preds, zero_division=0), 4),
        "recall": round(recall_score(y_test, preds, zero_division=0), 4),
        "f1": round(f1_score(y_test, preds, zero_division=0), 4),
        "roc_auc": round(roc_auc_score(y_test, probs), 4),
    }


def train_and_compare(df: pd.DataFrame, feature_cols: list[str], target_col: str = "machine_failure"):
    X = df[feature_cols]
    y = df[target_col]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    results, models = [], {}
    pos_weight = (y_train == 0).sum() / max((y_train == 1).sum(), 1)

    xgb_clf = xgb.XGBClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, eval_metric="logloss",
        random_state=42, scale_pos_weight=pos_weight,
    )
    xgb_clf.fit(X_train, y_train)
    p = xgb_clf.predict(X_test); pr = xgb_clf.predict_proba(X_test)[:, 1]
    results.append(_eval("xgboost", y_test, p, pr)); models["xgboost"] = xgb_clf

    lgb_clf = lgb.LGBMClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=42, verbose=-1,
        class_weight="balanced",
    )
    lgb_clf.fit(X_train, y_train)
    p = lgb_clf.predict(X_test); pr = lgb_clf.predict_proba(X_test)[:, 1]
    results.append(_eval("lightgbm", y_test, p, pr)); models["lightgbm"] = lgb_clf

    rf_clf = RandomForestClassifier(
        n_estimators=300, max_depth=10, random_state=42,
        class_weight="balanced", n_jobs=-1,
    )
    rf_clf.fit(X_train, y_train)
    p = rf_clf.predict(X_test); pr = rf_clf.predict_proba(X_test)[:, 1]
    results.append(_eval("random_forest", y_test, p, pr)); models["random_forest"] = rf_clf

    leaderboard = pd.DataFrame(results).sort_values("f1", ascending=False).reset_index(drop=True)
    best_name = leaderboard.iloc[0]["model"]
    best_model = models[best_name]

    joblib.dump(best_model, MODEL_DIR / "failure_classifier.joblib")
    joblib.dump(feature_cols, MODEL_DIR / "failure_classifier_features.joblib")
    leaderboard.to_csv(MODEL_DIR / "classifier_leaderboard.csv", index=False)

    return leaderboard, best_name, models, (X_test, y_test)
