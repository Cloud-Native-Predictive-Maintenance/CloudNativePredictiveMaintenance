"""SHAP-based explainability for the failure classifier."""
import joblib
import numpy as np
import shap
import pandas as pd
from pathlib import Path

MODEL_DIR = Path(__file__).resolve().parents[2] / "models"


def build_explainer(model_path: Path = None):
    model_path = model_path or (MODEL_DIR / "failure_classifier.joblib")
    model = joblib.load(model_path)
    return shap.TreeExplainer(model)


def top_contributing_factors(explainer, X_row: pd.DataFrame, top_n: int = 4) -> list[dict]:
    """X_row: single-row DataFrame with the model's feature columns.

    SHAP's output shape differs by model type:
      - XGBoost/LightGBM binary classifiers: (n_rows, n_features)
      - RandomForestClassifier (multi-output under the hood): (n_rows, n_features, n_classes)
    We always want the row-0, positive-class (index 1) contributions.
    """
    shap_values = explainer.shap_values(X_row)
    shap_values = np.asarray(shap_values)
    if shap_values.ndim == 3:
        vals = shap_values[0, :, 1]      # row 0, all features, positive class
    elif shap_values.ndim == 2:
        vals = shap_values[0]            # row 0, all features
    else:
        vals = shap_values
    contrib = pd.Series(vals, index=X_row.columns).sort_values(key=abs, ascending=False)
    factors = []
    for feat, val in contrib.head(top_n).items():
        factors.append({
            "feature": feat,
            "shap_value": round(float(val), 4),
            "direction": "increases risk" if val > 0 else "decreases risk",
        })
    return factors
