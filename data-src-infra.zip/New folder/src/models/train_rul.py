"""Train a Remaining-Useful-Life (RUL) regressor."""
import joblib
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import xgboost as xgb

MODEL_DIR = Path(__file__).resolve().parents[2] / "models"
MODEL_DIR.mkdir(exist_ok=True)

RUL_CAP = 130  # standard CMAPSS trick: cap RUL target (engines behave ~linearly near failure only)


def train_rul_model(df: pd.DataFrame, feature_cols: list[str]):
    df = df.copy()
    df["RUL_capped"] = df["RUL"].clip(upper=RUL_CAP)

    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_idx, test_idx = next(gss.split(df, groups=df["unit_number"]))
    X_train, X_test = df.iloc[train_idx][feature_cols], df.iloc[test_idx][feature_cols]
    y_train, y_test = df.iloc[train_idx]["RUL_capped"], df.iloc[test_idx]["RUL_capped"]

    model = xgb.XGBRegressor(
        n_estimators=400, max_depth=6, learning_rate=0.03,
        subsample=0.8, colsample_bytree=0.8, random_state=42,
    )
    model.fit(X_train, y_train)
    preds = model.predict(X_test)

    metrics = {
        "mae": round(mean_absolute_error(y_test, preds), 3),
        "rmse": round(np.sqrt(mean_squared_error(y_test, preds)), 3),
        "r2": round(r2_score(y_test, preds), 4),
    }

    joblib.dump(model, MODEL_DIR / "rul_regressor.joblib")
    joblib.dump(feature_cols, MODEL_DIR / "rul_regressor_features.joblib")

    return model, metrics, (X_test, y_test, preds)
