"""Train and compare failure-classification models (XGBoost, LightGBM, Random Forest)."""
import joblib
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score
import xgboost as xgb
import lightgbm as lgb

MODEL_DIR = Path(__file__).resolve().parents[2] / "models"
MODEL_DIR.mkdir(exist_ok=True)


def _split_by_unit(df: pd.DataFrame, target_col: str, feature_cols: list[str], test_size=0.2, seed=42):
    gss = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
    train_idx, test_idx = next(gss.split(df, groups=df["unit_number"]))
    X_train, X_test = df.iloc[train_idx][feature_cols], df.iloc[test_idx][feature_cols]
    y_train, y_test = df.iloc[train_idx][target_col], df.iloc[test_idx][target_col]
    return X_train, X_test, y_train, y_test


def _eval(name, y_test, preds, probs):
    return {
        "model": name,
        "precision": round(precision_score(y_test, preds, zero_division=0), 4),
        "recall": round(recall_score(y_test, preds, zero_division=0), 4),
        "f1": round(f1_score(y_test, preds, zero_division=0), 4),
        "roc_auc": round(roc_auc_score(y_test, probs), 4),
    }


def train_and_compare(df: pd.DataFrame, feature_cols: list[str], target_col: str = "failure_within_horizon"):
    X_train, X_test, y_train, y_test = _split_by_unit(df, target_col, feature_cols)
    results, models = [], {}

    xgb_clf = xgb.XGBClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, eval_metric="logloss",
        random_state=42, scale_pos_weight=(y_train == 0).sum() / max((y_train == 1).sum(), 1),
    )
    xgb_clf.fit(X_train, y_train)
    p = xgb_clf.predict(X_test); pr = xgb_clf.predict_proba(X_test)[:, 1]
    results.append(_eval("xgboost", y_test, p, pr)); models["xgboost"] = xgb_clf

    lgb_clf = lgb.LGBMClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=42, verbose=-1,
        class_weight="balanced",
    )
    lgb_clf.fit(X_train, y_train)
    p = lgb_clf.predict(X_test); pr = lgb_clf.predict_proba(X_test)[:, 1]
    results.append(_eval("lightgbm", y_test, p, pr)); models["lightgbm"] = lgb_clf

    rf_clf = RandomForestClassifier(
        n_estimators=300, max_depth=10, random_state=42,
        class_weight="balanced", n_jobs=-1,
    )
    rf_clf.fit(X_train, y_train)
    p = rf_clf.predict(X_test); pr = rf_clf.predict_proba(X_test)[:, 1]
    results.append(_eval("random_forest", y_test, p, pr)); models["random_forest"] = rf_clf

    leaderboard = pd.DataFrame(results).sort_values("f1", ascending=False).reset_index(drop=True)
    best_name = leaderboard.iloc[0]["model"]
    best_model = models[best_name]

    joblib.dump(best_model, MODEL_DIR / "failure_classifier.joblib")
    joblib.dump(feature_cols, MODEL_DIR / "failure_classifier_features.joblib")
    leaderboard.to_csv(MODEL_DIR / "classifier_leaderboard.csv", index=False)

    return leaderboard, best_name, models, (X_test, y_test)
