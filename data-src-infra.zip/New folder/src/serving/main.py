"""FastAPI serving layer for the predictive maintenance platform.

Endpoints:
  GET  /health                 - service liveness
  POST /predict                - C-MAPSS: failure prob, RUL, anomaly, SHAP factors (time-series sensor data)
  POST /predict/ai4i           - AI4I 2020: failure prob, anomaly, SHAP factors (per-instance tabular data)
  GET  /models/info            - which models are loaded / their metrics

Run locally:
  uvicorn src.serving.main:app --reload --port 8000
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import joblib
import pandas as pd
from datetime import datetime
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from src.models.explain import build_explainer, top_contributing_factors

MODEL_DIR = Path(__file__).resolve().parents[2] / "models"
MODEL_DIR_AI4I = Path(__file__).resolve().parents[2] / "models_ai4i"

app = FastAPI(
    title="Predictive Maintenance API",
    description="Failure prediction, anomaly detection, RUL estimation, and SHAP explainability for industrial sensor data.",
    version="1.0.0",
)
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

_state = {}


@app.on_event("startup")
def load_artifacts():
    try:
        _state["clf"] = joblib.load(MODEL_DIR / "failure_classifier.joblib")
        _state["clf_features"] = joblib.load(MODEL_DIR / "failure_classifier_features.joblib")
        _state["rul_model"] = joblib.load(MODEL_DIR / "rul_regressor.joblib")
        _state["rul_features"] = joblib.load(MODEL_DIR / "rul_regressor_features.joblib")
        _state["iso"] = joblib.load(MODEL_DIR / "anomaly_detector.joblib")
        _state["iso_scaler"] = joblib.load(MODEL_DIR / "anomaly_scaler.joblib")
        _state["iso_features"] = joblib.load(MODEL_DIR / "anomaly_features.joblib")
        _state["explainer"] = build_explainer()
        _state["ready"] = True
    except FileNotFoundError:
        _state["ready"] = False

    try:
        _state["ai4i_clf"] = joblib.load(MODEL_DIR_AI4I / "failure_classifier.joblib")
        _state["ai4i_clf_features"] = joblib.load(MODEL_DIR_AI4I / "failure_classifier_features.joblib")
        _state["ai4i_iso"] = joblib.load(MODEL_DIR_AI4I / "anomaly_detector.joblib")
        _state["ai4i_iso_scaler"] = joblib.load(MODEL_DIR_AI4I / "anomaly_scaler.joblib")
        _state["ai4i_iso_features"] = joblib.load(MODEL_DIR_AI4I / "anomaly_features.joblib")
        _state["ai4i_explainer"] = build_explainer(MODEL_DIR_AI4I / "failure_classifier.joblib")
        _state["ai4i_ready"] = True
    except FileNotFoundError:
        _state["ai4i_ready"] = False


class SensorReading(BaseModel):
    machine_id: str = Field(..., examples=["M-1024"])
    features: dict[str, float] = Field(
        ..., description="Engineered feature vector matching the classifier's feature columns"
    )


class AI4IReading(BaseModel):
    machine_id: str = Field(..., examples=["L47181"])
    air_temp_k: float
    process_temp_k: float
    rotational_speed_rpm: float
    torque_nm: float
    tool_wear_min: float
    type: str = Field(..., description="Product quality variant: L, M, or H")


class AI4IPredictionResponse(BaseModel):
    machine_id: str
    timestamp: str
    failure_probability: float
    health_status: str
    is_anomaly: bool
    anomaly_score: float
    top_contributing_factors: list[dict]
    recommended_action: str


class PredictionResponse(BaseModel):
    machine_id: str
    timestamp: str
    failure_probability: float
    health_status: str
    is_anomaly: bool
    anomaly_score: float
    estimated_rul_cycles: float
    top_contributing_factors: list[dict]
    recommended_action: str


def _health_status(prob: float) -> str:
    if prob >= 0.7:
        return "HIGH RISK"
    if prob >= 0.35:
        return "MODERATE RISK"
    return "HEALTHY"


def _recommended_action(status: str, is_anomaly: bool) -> str:
    if status == "HIGH RISK":
        return "Schedule preventive maintenance immediately."
    if status == "MODERATE RISK" or is_anomaly:
        return "Increase monitoring frequency and inspect at next opportunity."
    return "No action needed — continue normal operation."


@app.get("/health")
def health():
    return {"status": "ok", "models_loaded": _state.get("ready", False)}


@app.get("/models/info")
def models_info():
    if not _state.get("ready"):
        raise HTTPException(503, "Models not loaded. Run the training pipeline first.")
    leaderboard_path = MODEL_DIR / "classifier_leaderboard.csv"
    leaderboard = pd.read_csv(leaderboard_path).to_dict(orient="records") if leaderboard_path.exists() else []

    ai4i_leaderboard = []
    if _state.get("ai4i_ready"):
        ai4i_leaderboard_path = MODEL_DIR_AI4I / "classifier_leaderboard.csv"
        if ai4i_leaderboard_path.exists():
            ai4i_leaderboard = pd.read_csv(ai4i_leaderboard_path).to_dict(orient="records")

    return {
        "cmapss": {
            "failure_classifier": type(_state["clf"]).__name__,
            "rul_regressor": type(_state["rul_model"]).__name__,
            "anomaly_detector": type(_state["iso"]).__name__,
            "classifier_leaderboard": leaderboard,
        },
        "ai4i": {
            "ready": _state.get("ai4i_ready", False),
            "failure_classifier": type(_state["ai4i_clf"]).__name__ if _state.get("ai4i_ready") else None,
            "anomaly_detector": type(_state["ai4i_iso"]).__name__ if _state.get("ai4i_ready") else None,
            "classifier_leaderboard": ai4i_leaderboard,
        },
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(reading: SensorReading):
    if not _state.get("ready"):
        raise HTTPException(503, "Models not loaded. Run the training pipeline first (python run_pipeline.py).")

    clf_features = _state["clf_features"]
    missing = [f for f in clf_features if f not in reading.features]
    if missing:
        raise HTTPException(422, f"Missing {len(missing)} required features, e.g. {missing[:5]}")

    X = pd.DataFrame([{f: reading.features[f] for f in clf_features}])
    prob = float(_state["clf"].predict_proba(X)[0, 1])
    status = _health_status(prob)

    X_rul = pd.DataFrame([{f: reading.features[f] for f in _state["rul_features"]}])
    rul = float(_state["rul_model"].predict(X_rul)[0])

    X_iso = pd.DataFrame([{f: reading.features[f] for f in _state["iso_features"]}])
    X_iso_scaled = _state["iso_scaler"].transform(X_iso)
    anomaly_score = float(_state["iso"].decision_function(X_iso_scaled)[0])
    is_anomaly = bool(_state["iso"].predict(X_iso_scaled)[0] == -1)

    factors = top_contributing_factors(_state["explainer"], X, top_n=4)

    return PredictionResponse(
        machine_id=reading.machine_id,
        timestamp=datetime.utcnow().isoformat(),
        failure_probability=round(prob, 4),
        health_status=status,
        is_anomaly=is_anomaly,
        anomaly_score=round(anomaly_score, 4),
        estimated_rul_cycles=round(rul, 1),
        top_contributing_factors=factors,
        recommended_action=_recommended_action(status, is_anomaly),
    )


@app.post("/predict/ai4i", response_model=AI4IPredictionResponse)
def predict_ai4i(reading: AI4IReading):
    if not _state.get("ai4i_ready"):
        raise HTTPException(503, "AI4I models not loaded. Run python run_pipeline_ai4i.py first.")

    import numpy as np

    row = {
        "air_temp_k": reading.air_temp_k,
        "process_temp_k": reading.process_temp_k,
        "rotational_speed_rpm": reading.rotational_speed_rpm,
        "torque_nm": reading.torque_nm,
        "tool_wear_min": reading.tool_wear_min,
        "temp_diff_k": reading.process_temp_k - reading.air_temp_k,
        "power_w": reading.torque_nm * reading.rotational_speed_rpm * (2 * np.pi / 60),
        "wear_torque_interaction": reading.tool_wear_min * reading.torque_nm,
        "type_H": 1 if reading.type == "H" else 0,
        "type_L": 1 if reading.type == "L" else 0,
        "type_M": 1 if reading.type == "M" else 0,
    }

    clf_features = _state["ai4i_clf_features"]
    X = pd.DataFrame([{f: row.get(f, 0.0) for f in clf_features}])
    prob = float(_state["ai4i_clf"].predict_proba(X)[0, 1])
    status = _health_status(prob)

    iso_features = _state["ai4i_iso_features"]
    X_iso = pd.DataFrame([{f: row.get(f, 0.0) for f in iso_features}])
    X_iso_scaled = _state["ai4i_iso_scaler"].transform(X_iso)
    anomaly_score = float(_state["ai4i_iso"].decision_function(X_iso_scaled)[0])
    is_anomaly = bool(_state["ai4i_iso"].predict(X_iso_scaled)[0] == -1)

    factors = top_contributing_factors(_state["ai4i_explainer"], X, top_n=4)

    return AI4IPredictionResponse(
        machine_id=reading.machine_id,
        timestamp=datetime.utcnow().isoformat(),
        failure_probability=round(prob, 4),
        health_status=status,
        is_anomaly=is_anomaly,
        anomaly_score=round(anomaly_score, 4),
        top_contributing_factors=factors,
        recommended_action=_recommended_action(status, is_anomaly),
    )
